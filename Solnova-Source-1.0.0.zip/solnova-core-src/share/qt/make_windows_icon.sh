#!/bin/bash
# create multiresolution windows icon
#mainnet
ICON_SRC=../../src/qt/res/icons/bitcoin.png
ICON_DST=../../src/qt/res/icons/bitcoin.ico
convert ${ICON_SRC} -resize 16x16 bitcoin-16.png
convert ${ICON_SRC} -resize 32x32 bitcoin-32.png
convert ${ICON_SRC} -resize 48x48 bitcoin-48.png
convert ${ICON_SRC} -resize 96x96 bitcoin-96.png
convert ${ICON_SRC} -resize 128x128 bitcoin-128.png
convert ${ICON_SRC} -resize 256x256 bitcoin-256.png
convert ${ICON_SRC} -resize 512x512 bitcoin-512.png
convert bitcoin-16.png bitcoin-32.png bitcoin-48.png bitcoin-96.png bitcoin-128.png bitcoin-256.png bitcoin-512.png ${ICON_DST}
#testnet
ICON_SRC=../../src/qt/res/icons/bitcoin_testnet.png
ICON_DST=../../src/qt/res/icons/bitcoin_testnet.ico
convert ${ICON_SRC} -resize 16x16 bitcoin-16.png
convert ${ICON_SRC} -resize 32x32 bitcoin-32.png
convert ${ICON_SRC} -resize 48x48 bitcoin-48.png
convert ${ICON_SRC} -resize 96x96 bitcoin-96.png
convert ${ICON_SRC} -resize 128x128 bitcoin-128.png
convert ${ICON_SRC} -resize 256x256 bitcoin-256.png
convert ${ICON_SRC} -resize 512x512 bitcoin-512.png
convert bitcoin-16.png bitcoin-32.png bitcoin-48.png bitcoin-96.png bitcoin-128.png bitcoin-256.png bitcoin-512.png ${ICON_DST}
