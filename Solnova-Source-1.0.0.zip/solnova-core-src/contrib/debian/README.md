
Debian
====================
This directory contains files used to package solnovad/solnova-qt
for Debian-based Linux systems. If you compile solnovad/solnova-qt yourself, there are some useful files here.

## solnova: URI support ##


solnova-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install solnova-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your solnovaqt binary to `/usr/bin`
and the `../../share/pixmaps/solnova128.png` to `/usr/share/pixmaps`

solnova-qt.protocol (KDE)

