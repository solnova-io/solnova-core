Sample configuration files for:

SystemD: solnovad.service
Upstart: solnovad.conf
OpenRC:  solnovad.openrc
         solnovad.openrcconf
CentOS:  solnovad.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
