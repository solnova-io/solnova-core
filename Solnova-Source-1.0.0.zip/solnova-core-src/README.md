Solnova Core Staging Repository (Version 1.0.0)
===========================

What is Solnova Core?
-------------

Solnova is an experimental digital currency that enables instant, private
payments to anyone, anywhere in the world. Solnova uses peer-to-peer technology
to operate with no central authority: managing transactions and issuing money
are carried out collectively by the network. Solnova Core is the name of the open
source software which enables the use of this currency.


License
-------

Solnova Core is released under the terms of the MIT license. See [COPYING](COPYING) for more
information or see https://opensource.org/licenses/MIT.
